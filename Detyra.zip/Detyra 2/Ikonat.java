import javax.swing.*;
import java.io.*;
import java.util.Scanner;
import java.awt.*;
public class Ikonat  
{
   static Ikonat [] vargu = new Ikonat[100];
   static int a;    // a - indeksi prej te cilit klasa fut veten ne varg
   int b ;         // b - indeksi i tanishem i klases ne vargun "vargu"
 
   private ImageIcon fotoja ; // fotoja qe vizatohet
 
   File file;  //fajlli ne te cilin ndodhet txt dokumenti qe perdoret prej objketit
 
   private int sasia,indeksi; // indeksi - e sata me rend eshte ne varg
 
   private String lloji,emri,cmimi,afati; // te dhena te pergjithshme mbi produktin
 
   public Ikonat (String emri,String lloji) throws IOException
   { 
      this.emri = emri;
      this.lloji = lloji;
      if(shikoVargun(emri))  // nese obj ekziston me heret mos e rikrijo
         return;
      file = new File(new String (emri+".txt")); 
   
      if(file.exists()==false)   //Nese fajlli nuk ekziston atehere e inicializon "file". 
      {  
         file.createNewFile();
     
         shkruaj();
      }
      else 
      {
         lexo();                 // Nese "file ekziston atehere vetem i lexon vlerat e tij  
      }
     
      File file_1 = new File("Fotot\\"+lloji+".png"); //Vendi ku gjinget "fotoja" 
   
      if(file_1.exists())               // Nese file_1 ekziston "file_1" e merr vleren nga file_1
         fotoja = new ImageIcon("Fotot\\"+lloji+".png"); 
      
      else
         fotoja = new ImageIcon("Fotot\\NULL.png"); // kur fotoja nuk gjindet     
        b =a;
      vargu[a] = this;
      a++;
   }
   void jepAfatin(String a){
      afati = a;
   }
   void jepCmimin(String a){
      cmimi = a;
   }
   void jepSasine (int a){
      sasia = a;
   }
   int merrIndeksin(){
      return b;
   }
   ImageIcon merrFoton(){
      return fotoja;
   }
   String merrLlojin(){
      return lloji;
   }
   String merrEmrin(){
      return emri;
   }
   int merrSasine(){
      return sasia;
   }
   String merrCmimin(){
      return cmimi;
   }
   String merrAfatin(){
      return afati;
   }
    String lexoRreshtin (int i) throws FileNotFoundException  // Lexon rreshtin e i (duke filluar nga 0)
   {                                        //te nje txt dokumenti duke perdorur klasen "Scanner".             
      Scanner A = new Scanner(file);
      String b = null;
   
      for(int j = 0;j<=i;j++)
      {
         if(i==j)
            b = A.nextLine();
         
         else 
            A.nextLine();
      
      } 
      A.close();
      return b;
   }

   void shkruaj () throws FileNotFoundException //Shkruan ne "file" (txt dokument) te dhenat e pergjithsme te  
   {                                           // te objektit .
      PrintWriter shkruesi = new PrintWriter(file);
      shkruesi.println(lloji);
      shkruesi.println(emri);
      shkruesi.println(sasia);
      shkruesi.println(cmimi);
      shkruesi.println(afati);
      shkruesi.close();
   }
   void lexo() throws FileNotFoundException // I jep vlera te dhenave te pergjithshme te objektit duke lexuar 
   {                                       // ato nga "file"(txt dokument).
      lloji = lexoRreshtin (0);
      emri = lexoRreshtin(1);
      sasia = new Integer(lexoRreshtin(2));
      cmimi = lexoRreshtin(3);
      afati = lexoRreshtin(4);
    
   }
   boolean shikoVargun(String emri) // kerkon vargun per te gjetur objekt te tipit Ikonat me emer te njejte,
   {                               // nese e gjen kthe "true" ,e nese jo kthen "false".
      boolean rez = false;
      for(int i = 0;i<a;i++)
         if(vargu[i].merrEmrin().equals(emri))
            rez = true;
    
      return rez;
   }
  
   static int gjejProduktin (String e) //Kthen indeksin e produktit ne varg
   {
      int rez = -1;
      for(int i = 0;i<a;i++)
         if(vargu[i].emri.equals(e))
            rez = i;
      return rez;  
   } 
   void fshijProduktin ()  // fshin produktin perkates nga vargu dhe e rregullon vargun qe te mos kete "zbrazetira"  
   {                      // gjithashtu fshin "file" (txt dokumentin).
   
      if(file.exists())
         file.delete();
         
      if(b == Ikonat.vargu.length-1 ) //(vargu.length -1) - elementi i fundit ne varg
      {
      Ikonat.vargu[Ikonat.a-1] = null;
      return;
      }
      else 
         for(int i = b;i<Ikonat.a;i++)
            {
             Ikonat.vargu[i].b--; 
             Ikonat.vargu[i] = Ikonat.vargu[i+1];
            }   
      Ikonat.a--; 
   
   }  
 

}