import java.io.*;
import java.util.*;
import javax.swing.*;
public class Provuese 
{
 static Krijo a ;
 public static void main (String [] args)
 {
 try{
   a = new Krijo ();
  Vizatuesi viz = new Vizatuesi();
  VizatoAnash c = new VizatoAnash();
 
  
  while(0<10){
   if(c.merrDritare().isShowing())
   {
    viz.repaint();}
   else
    if(c.vizatoAnash())
     {a.perfundo();
      c = null;
      break;
      }
     
  }
 
}
 
 catch(Exception e)
 {
 System.out.println("khuuu qfar exception hahha"+e);

 }  
 }
}