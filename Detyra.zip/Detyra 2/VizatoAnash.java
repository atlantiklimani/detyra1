import java.io.*;
import java.awt.*;
import javax.swing.*;
class VizatoAnash  extends JPanel
{ private JOptionPane obj;
   private int x_pos,y_pos,d,indeksi; // x_pos ,y_pos prej ku fillon te vizatohet fotoja ne vartesi te dritares se vogel,
                                  // d-dallimi ne largesi ne mes vizatimev,indeksi qe kthehet nga emri i jepur
   private JFrame dritarja ;
  
   public VizatoAnash() 
   {
      fillo_1();
   }
  
   JFrame merrDritare(){
   return dritarja;}
   boolean vizatoAnash() throws IOException  // Hap nje dritare(JOptionPane) dhe pyet se cka do te bej
   {                         //nese shtypet butoni cancel programi mbyllet(ne menyre te kontrolluar pa exception)     
                  //nese shtypet "shto" shfrytezuesi do te pytet per emrin dhe llojin e produktit dhe nese shtypet
                   //emri i produktit ekzistues i jep vler ndryshores "indeks".Kthen true nese nuk doni ta mbyllni programin
      boolean rez = false;
      String hyrja =  obj.showInputDialog("Shtyp cancel per ta mbyllur programin" +
                                                "\nShtyp \"shto\" per te shtuar produkte " +" \nCilin produkt");
      if(hyrja == null)
         rez = true;
         
      else if(hyrja.toUpperCase().trim().equals("SHTO"))
      {
         hyrja = obj.showInputDialog("Jep emrin");
         while(true)
            if(hyrja == null || hyrja.trim().equals(""))
            {
               obj.showMessageDialog(null,"Emri nuk guxon te jete i zbrazet \n dhe duhet te jipet me butonin\"OK\" me tastin Enter");
               hyrja = obj.showInputDialog("Jep emrin");
               continue ;
            }
            else 
               break;
         hyrja = hyrja.trim();
         String hyrja_1 = obj.showInputDialog("Jep llojin");
         while(true)
            if(hyrja_1 == null || hyrja_1.trim().equals(""))
            {
               obj.showMessageDialog(null,"Lloji nuk guxon te jete i zbrazet \n dhe duhet te jipet me butonin \"OK\" ose tastin Enter"); 
               hyrja_1 = obj.showInputDialog("Jep llojin");
               continue ;
            }   
            else 
               break;
         hyrja_1 = hyrja_1.trim();
         new Ikonat(hyrja, hyrja_1);}
      int indeksi = Ikonat.gjejProduktin(hyrja);
      this.indeksi = indeksi;
      if(indeksi!=-1)
      { 
         fillo();
         jepVlerat();
      }
      return rez;
   }
 
   int merrIndeksin(){
      return indeksi;}
 
   void fillo_1() //I jep vlere JFrame-it dhe ndryshorev te fushes
   { obj = new JOptionPane();
      dritarja = new JFrame();
      dritarja.getContentPane().add(this);
      x_pos = 5;
      y_pos = 5;
      d=20;
   
   }
 
   void fillo() //Sa here qe kerkohet nje emer i produktit valid thirret metoda fillo duke e paraqitur dritaren
   {            //(JFrame-in) ne vartesi te dritares kryesore  
      dritarja.setTitle(Ikonat.vargu[indeksi].merrEmrin());
      dritarja.setSize(110,Vizatuesi.merrMadhesite().getSize().height);
      dritarja.setLocation(Vizatuesi.merrDritaren().getX()+Vizatuesi.merrDritaren().getSize().width,Vizatuesi.merrDritaren().getY());
      dritarja.setVisible(true);
   
   
   }
 
   public void paintComponent(Graphics g)
   {super.paintComponent (g);
      shfaq(g);
   }
 
   void shfaq(Graphics g)// I vizaton te dhenat e pergjithsme te produktit ne dritaren (JFrame)
   { 
      Ikonat iko = Ikonat.vargu[indeksi];
      iko.merrFoton().paintIcon(this,g,x_pos,y_pos);
      g.setColor(Color.black);
      g.drawString(iko.merrEmrin(),x_pos,y_pos+105+d);
      g.drawString("Lloji : "+iko.merrLlojin(),x_pos,y_pos+105+2*d);
      g.drawString("Sasia : "+iko.merrSasine(),x_pos,y_pos+105+3*d);
      g.drawString("Cmimi : "+iko.merrCmimin()+"$",x_pos,y_pos+105+4*d);
      g.drawString("Afati : "+iko.merrAfatin(),x_pos,y_pos+105+5*d);
   }
   void jepVlerat() throws FileNotFoundException //Pyet shfrytezuesin se cka do te bej me produktin(te ndryshoje 
     {                              //ndonje te dhe te pergjitshme te tij ose ta fshij ate).
      Ikonat iko =  Ikonat.vargu[indeksi];    
      String a  =  new JOptionPane().showInputDialog(" 1 - sasia\n 2 - cmimi\n 3 - afati\n 123 - per te trija"+
                                                          "\n 4 - per te fshire produktin  ");
   
      String b;
   
      if(a == null)
      {
         return;
      }
      
      else if (a.trim().equals(""))
         return; 
      
      else
      {JOptionPane obj = new JOptionPane();
         switch (a.trim())
         {
            case("1") :
               {
                  b  = obj.showInputDialog("Shtyp zbrazetire per te ruajtur vleren paraprake te sasise "
                                                +"\n Ose jep vleren ");
                                                
                  if(b==null)
                  { obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
                     return ;}
                  b=b.trim();
                  if(b.equals("")) ;
                  
                  else if(ktheVlefshmerine(b))
                     iko.jepSasine(new Integer(b).intValue());
                    
                  
                  else 
                     obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
               
                  break;
               }
            case("2") :
               {
                  b  = obj.showInputDialog("Shtyp zbrazetire per te ruajtur cmimin paraprak "
                                                +"\n Ose jep vleren ");
                  if(b==null){
                     obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
                     return;}
                  b= b.trim();                                          
               
                  if(b.equals("")) ;
                  else 
                     iko.jepCmimin(b);
                  break; 
               }
            case("3") :
               {
                  b  = obj.showInputDialog("Shtyp zbrazetire per te ruajtur afatin paraprak "
                                                    +"\n Ose jep vleren ");
                  if(b==null){
                     obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
                     return;
                  }                                               
                  b = b.trim();
                  if(b.equals(""));
                  else
                     iko.jepAfatin(b);
                  break;
               }
            case("123") : 
               {
                  b  = obj.showInputDialog("Shtyp zbrazetire per te ruajtur vleren paraprake te sasise " 
                                                +"\n Ose jep vleren ");
                  if(b==null){
                     obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
                     return;}
               
                  b = b.trim();
                  if(b.equals("")) ;
                  else if(ktheVlefshmerine(b))
                    { iko.jepSasine( new Integer(b).intValue()); repaint();}
                  else
                  { obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");}
               
               
                  b  = obj.showInputDialog("Shtyp zbrazetire per te ruajtur cmimin paraprak "
                                                +"\n Ose jep vleren ");
                  if(b==null){
                     obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
                     return;}
                  b = b.trim(); 
                  if(b.equals("")) ;
                  else 
                     {iko.jepCmimin(b); repaint();}
               
                  b  = obj.showInputDialog("Shtyp zbrazetire per te ruajtur afatin paraprak "
                                                +"\n Ose jep vleren ");
                  if(b==null){
                     obj.showMessageDialog(null,"Vlera juaj nuk eshte e vlefshme");
                     return;}
                  b = b.trim();
                  if(b.equals(""));
                  else
                     {iko.jepAfatin(b); repaint();}
                  break;
               }
            case("4"):
               {
                  iko.fshijProduktin();
                  return;
               }
            default :
               break;
         }
         iko.shkruaj();
         repaint();
      }
   
   }
   boolean ktheVlefshmerine(String a) //Kontrollon Stringun hyres nese ka ndonje karakter te ndryshem prej numrit
   {                                //nese ka shkronja kthen false nese ka vetem numra kthen true.
      boolean rez = false; 
      for(int i = 0;i<a.length();i++)
      {
         if(a.charAt(i) < 48||a.charAt(i)>57)
         {
            rez = false;
            break;
         }
         if(a.charAt(i) >= 48 && a.charAt(i) <=57)
            rez = true;
      }
      return rez;
   }
 
}