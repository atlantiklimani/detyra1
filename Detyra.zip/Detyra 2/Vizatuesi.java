import java.util.*;
import javax.swing.*;
import java.awt.*;
class Vizatuesi extends JPanel 
{
 
 private static Rectangle k ; //per te ruajtur dimensionet e JFrame-it si katror per perdorim te metutjeshem

 static JFrame d ;  

 int  m =110; // m - madhesia  e ikonave te produktev

 Vizatuesi () // Konstruktori i jep JFrame - it dimensionet dhe panelen, pastaj e shfaq ne ekran
 {
 d = new JFrame();
 d.setSize(400,400);
 d.getContentPane().add(this);
 d.setVisible(true);
 d.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 }
 
 static Rectangle merrMadhesite(){   //kthen dimensionet  e JFrame-it.
 return k; }
 
 static JFrame merrDritaren(){     // kthen JFrame-in.
 return d; }

 void vizato(Graphics g) // Per secilin objekt (te tipit "Ikonat") te krijuar e vizaton foton e tij dhe emrin 
 {                      // nen foto. 
  g.setColor(Color.black);
  int a = 0;     //ineksi i anetarit ne vargun e "Ikonat"-ve.       
  
  k = d.getBounds();
 Fillimi :  
  for(int j = 0;j<(int)(k.getSize().height/m);j++)  //I vizaton fotot ne menyre qe ato te mos mbesin jashte dritares
    for(int i = 0;i<(int)(k.getSize().width/m);i++)
    {
     if(Ikonat.vargu[a]==null) //Kur anetari i a-te i vargut te Ikonave eshte null ndalo se vizatuari
      {
      break Fillimi;  
      }  
     Ikonat.vargu[a].merrFoton().paintIcon(this,g,i*100+5*i,j*100+18*j);
     g.drawString(Ikonat.vargu[a].merrEmrin(),i*100+5*i+15,j*100+18*j+115);
     a++; 
    }
 }
 public void paintComponent(Graphics g) //Vizaton Ikonat se bashku me emrat 
 {
  super.paintComponent(g);
  g.setColor(new Color(100,30,45,90));
  g.fillRect(0,0,1000,1000);
  vizato(g);

 }
 

  
}
