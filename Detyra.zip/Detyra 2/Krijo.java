import java.util.Scanner;
import java.io.*;
public class Krijo 
{
 private File file_1 = new File("Objekti.txt"); // Fajlli ku ruhen emrat dhe llojet e produktev rresht pas rreshti
 public Krijo () throws IOException,FileNotFoundException
 { 
   fillo();
 }
 void fillo() throws IOException,FileNotFoundException //E kontrollon nese ekziston file_1  dhe i krijon objektet 
 {                                    //Ikonat nga ai txt dokument,nese nuk ekziston e krjon nje txt dokument
    if(file_1.exists())
      {  
         String b = null;
         Scanner lexuesi = new Scanner(file_1);
         while(lexuesi.hasNextLine())
         {
          b = lexuesi.nextLine(); 
          System.out.println(b);  
          new Ikonat(b.substring(0,b.indexOf(' ')),b.substring(b.indexOf(' ')+1));   
         }
         lexuesi.close();
      }  
    else 
        file_1.createNewFile();

 }
 void perfundo() throws FileNotFoundException,IOException //Shkruan secilin produkt qe gjindet tek Ikonat.vargu 
 {                                              // ne "file_1"(txt dokument)        
   
    PrintWriter p = new PrintWriter(file_1); 
    for(int i = 0;i<Ikonat.a;i++)
     {
     System.out.println(Ikonat.vargu[i].merrEmrin());
     p.println(Ikonat.vargu[i].merrEmrin()+" "+Ikonat.vargu[i].merrLlojin());
    }
    p.close();
 }
   
}